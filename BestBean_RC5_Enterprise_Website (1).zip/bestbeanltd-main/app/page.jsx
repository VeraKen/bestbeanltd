import AskAdeCorporate from "./components/AskAdeCorporate";
import SiteHeader from "./components/SiteHeader";
import SiteFooter from "./components/SiteFooter";

import { portfolio } from "../lib/portfolio";

const operatingModel = [
  ["Discover", "Define the institutional problem, users, economics and measurable outcome."],
  ["Design", "Shape the strategy, solution architecture, commercial model and implementation plan."],
  ["Build", "Develop, configure or integrate the right platform and technology ecosystem."],
  ["Deploy", "Manage rollout, training, governance, adoption and operational readiness."],
  ["Scale", "Measure results, strengthen performance and expand across users and institutions."],
];

const enterpriseProof = [
  "Africa-focused execution",
  "Board and executive advisory",
  "Government-grade delivery discipline",
  "Education-sector specialization",
  "Platform ownership and product development",
  "Technology partnerships and licensing",
];

export default function Home() {
  return (
    <main>
      <SiteHeader />

      <section className="hero" id="top">
        <div className="heroText">
          <p className="eyebrow">BestBean Ltd • Parent Technology Company</p>
          <h1>We build AI solutions that create measurable outcomes.</h1>
          <p className="lead">
            BestBean Ltd develops and delivers technology platforms for education,
            government and enterprise—combining owned products, strategic partnerships
            and implementation expertise under one company.
          </p>
          <div className="actions">
            <a className="btn primary" href="#portfolio">Explore Our Portfolio</a>
            <a className="btn secondary" href="#contact">Request Executive Consultation</a>
          </div>
          <div className="stats">
            <div><strong>6</strong><span>Strategic Business Lines</span></div>
            <div><strong>AI</strong><span>Outcome-Led Solutions</span></div>
            <div><strong>Africa</strong><span>Built to Scale</span></div>
          </div>
        </div>

        <div className="portfolioMap" aria-label="BestBean portfolio structure">
          <div className="parentNode">
            <span className="nodeMark">B</span>
            <div><small>Parent Company</small><strong>BestBean Ltd</strong></div>
          </div>
          <div className="mapLine" />
          <div className="mapGrid">
            {portfolio.map((item) => (
              <div className={`mapNode ${item.featured ? "mapFeatured" : ""}`} key={item.title}>
                <span>{item.number}</span>
                <div><strong>{item.title}</strong><small>{item.label}</small></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="trustStrip">
        <span>One Company. Multiple Growth Engines.</span>
        <b>Owned Platforms</b>
        <b>Government Solutions</b>
        <b>Education Technology</b>
        <b>Enterprise Advisory</b>
        <b>SaaS Innovation</b>
      </section>

      <section className="portfolioSection cream" id="portfolio">
        <div className="sectionIntro">
          <div>
            <p className="eyebrow dark">BestBean Portfolio</p>
            <h2>A focused portfolio built around institutional outcomes.</h2>
          </div>
          <p>
            Each business line has a distinct customer, commercial role and growth path.
            Together they position BestBean as both a technology-product company and a
            trusted implementation partner.
          </p>
        </div>

        <div className="portfolioCards">
          {portfolio.map((item) => (
            <article className={`portfolioCard ${item.featured ? "featuredCard" : ""}`} key={item.title}>
              <div className="portfolioTop">
                <span className="portfolioNumber">{item.number}</span>
                <span className="portfolioLabel">{item.label}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <div className="portfolioBottom">
                <small>{item.audience}</small>
                <a href={`/solutions/${item.slug}`}>Explore Solution →</a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="platformSpotlight">
        <div>
          <p className="eyebrow">Flagship Platform</p>
          <h2>ExamSphere turns exam preparation into a measurable learning journey.</h2>
          <p>
            Adaptive practice, unique question generation, weak-topic analysis, student
            success reporting, parent visibility and Ask Ade AI tutoring—built for WAEC,
            JAMB and the broader African examination market.
          </p>
          <div className="pills darkPills">
            <span>Adaptive Learning</span><span>Student Intelligence</span><span>Parent Reports</span><span>Ask Ade AI Tutor</span>
          </div>
          <a className="btn primary" href="/solutions/examsphere">Explore ExamSphere.app</a>
        </div>
        <div className="spotlightPanel">
          <span className="spotlightTag">BestBean Product Company</span>
          <div className="spotlightMetric"><strong>Student</strong><span>Practice. Learn. Improve. Pass.</span></div>
          <div className="spotlightMetric"><strong>Parent</strong><span>Visibility into progress and readiness.</span></div>
          <div className="spotlightMetric"><strong>School</strong><span>Actionable performance intelligence.</span></div>
        </div>
      </section>

      <section className="method cream" id="model">
        <div className="sectionIntro">
          <div><p className="eyebrow dark">BestBean Operating Model</p><h2>From problem definition to scaled results.</h2></div>
          <p>We combine strategy, product thinking, technology implementation and adoption support so clients receive an operating solution—not merely a recommendation.</p>
        </div>
        <div className="operatingGrid">
          {operatingModel.map(([title, text], index) => (
            <article key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{text}</p></article>
          ))}
        </div>
      </section>

      <section className="governmentSection">
        <div>
          <p className="eyebrow">Government & Institutional Solutions</p>
          <h2>Designed for complexity, accountability and national scale.</h2>
        </div>
        <div className="proofGrid">
          {enterpriseProof.map((item) => <p key={item}>{item}</p>)}
        </div>
      </section>

      <section className="leadership" id="leadership">
        <div className="portrait">KS</div>
        <div>
          <p className="eyebrow dark">Leadership</p>
          <h2>Kenneth Spann, JD, MBA</h2>
          <p>
            Founder and Principal Consultant with experience spanning technology leadership,
            enterprise consulting, education, commercial strategy and international market development.
          </p>
          <div className="pills"><span>Technology Strategy</span><span>Enterprise Consulting</span><span>Education Innovation</span><span>Market Development</span></div>
        </div>
      </section>

      <section className="contact cream" id="contact">
        <div>
          <p className="eyebrow dark">Executive Consultation</p>
          <h2>Bring us the outcome you need to create.</h2>
          <p>Discuss AI transformation, government programs, education technology, ExamSphere partnerships, BenQ deployments, device management or a new SaaS opportunity.</p>
        </div>
        <div className="contactCard">
          <span className="contactLabel">BestBean Ltd</span>
          <a href="mailto:Ken.Spann@bestbeanltd.com">Ken.Spann@bestbeanltd.com</a>
          <a href="mailto:info@bestbeanltd.com">info@bestbeanltd.com</a>
          <span>Lagos, Nigeria</span>
          <a className="contactButton" href="mailto:Ken.Spann@bestbeanltd.com?subject=BestBean%20Executive%20Consultation">Request Consultation</a>
        </div>
      </section>

      <SiteFooter />
      <AskAdeCorporate />
    </main>
  );
}
